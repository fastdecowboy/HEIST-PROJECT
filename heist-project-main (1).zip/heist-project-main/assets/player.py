from assets.map import *

inventory = []

current_room = room_lobby